import pandas as pd
import numpy as np
import re
import torch
import matplotlib.pyplot as plt
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset

nltk.download('punkt')
nltk.download('stopwords')

# Define datasets and paths
DATASETS = {
    "Grover": "datasets/grover_dataset.csv",
    "FakeNewsNet": "datasets/fakenewsnet_dataset.csv",
    "LIAR": "datasets/liar_dataset.csv",
    "FakenewsAI": "datasets/fakenewsai_dataset.csv",
    "GPT-2": "datasets/gpt2_dataset.csv"
}

# Function to clean text
def clean_text(text):
    text = re.sub(r"http\S+|www\S+|https\S+", '', text)
    text = re.sub(r'\W', ' ', text)
    text = text.lower()
    tokens = word_tokenize(text)
    tokens = [word for word in tokens if word not in stopwords.words('english')]
    return " ".join(tokens)

# Function to process dataset
def load_and_preprocess_dataset(filepath):
    df = pd.read_csv(filepath)
    df = df[['text', 'label']]  # Ensure dataset has 'text' and 'label' columns
    df.dropna(inplace=True)
    df['clean_text'] = df['text'].apply(clean_text)
    return df

# Load and preprocess datasets
processed_datasets = {}
for name, path in DATASETS.items():
    try:
        processed_datasets[name] = load_and_preprocess_dataset(path)
        print(f"{name} dataset loaded successfully!")
    except Exception as e:
        print(f"Error loading {name}: {e}")

# BERT Tokenizer
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

# Function to tokenize dataset
def tokenize_dataset(df):
    return tokenizer(list(df['clean_text']), padding=True, truncation=True, max_length=512, return_tensors="pt")

# Fine-tune BERT model on each dataset
def train_model(dataset_name, df):
    print(f"\nTraining model on {dataset_name} dataset...")

    # Split into training and testing sets
    train_texts, test_texts, train_labels, test_labels = train_test_split(
        df['clean_text'], df['label'], test_size=0.2, random_state=42
    )

    # Convert to Hugging Face dataset
    train_encodings = tokenize_dataset(pd.DataFrame({'clean_text': train_texts}))
    test_encodings = tokenize_dataset(pd.DataFrame({'clean_text': test_texts}))

    train_dataset = Dataset.from_dict({
        "input_ids": train_encodings["input_ids"],
        "attention_mask": train_encodings["attention_mask"],
        "labels": list(train_labels)
    })

    test_dataset = Dataset.from_dict({
        "input_ids": test_encodings["input_ids"],
        "attention_mask": test_encodings["attention_mask"],
        "labels": list(test_labels)
    })

    # Load pre-trained model
    model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

    # Training arguments
    training_args = TrainingArguments(
        output_dir=f"./results/{dataset_name}",
        evaluation_strategy="epoch",
        save_strategy="epoch",
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        num_train_epochs=3,
        logging_dir=f"./logs/{dataset_name}",
        logging_steps=10,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=test_dataset,
    )

    trainer.train()

    # Evaluate model
    predictions = trainer.predict(test_dataset)
    preds = np.argmax(predictions.predictions, axis=-1)
    accuracy = accuracy_score(test_labels, preds)
    precision = precision_score(test_labels, preds)
    recall = recall_score(test_labels, preds)
    f1 = f1_score(test_labels, preds)

    return accuracy, precision, recall, f1

# Train and evaluate models on each dataset
results = {}
for dataset_name, df in processed_datasets.items():
    accuracy, precision, recall, f1 = train_model(dataset_name, df)
    results[dataset_name] = {
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1 Score": f1
    }
    print(f"\n{dataset_name} Benchmarking Results:")
    print(f"Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1 Score: {f1:.4f}")

# Plot results
dataset_names = list(results.keys())
accuracy_scores = [results[d]["Accuracy"] for d in dataset_names]

plt.figure(figsize=(10, 5))
plt.bar(dataset_names, accuracy_scores, color=['blue', 'green', 'red', 'purple', 'orange'])
plt.xlabel("Datasets")
plt.ylabel("Accuracy")
plt.title("Fake News Detection Model Accuracy on Different Datasets")
plt.xticks(rotation=15)
plt.show()
