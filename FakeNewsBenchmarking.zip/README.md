# Fake News Dataset Benchmarking

This project benchmarks multiple fake news datasets to determine their effectiveness in training AI-generated fake news detection models.

## 📌 Features
- Preprocesses and cleans datasets
- Fine-tunes a BERT-based classifier on each dataset
- Evaluates accuracy, precision, recall, and F1-score
- Visualizes results with bar charts

## 📂 Files
- `benchmarking.py` - Main script to run benchmarking
- `datasets/` - Folder to place dataset files
- `requirements.txt` - Install dependencies
- `README.md` - Project documentation

## 🚀 Setup & Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Download datasets into `datasets/` folder.
3. Run the benchmarking script:
   ```bash
   python benchmarking.py
   ```

## 📊 Output
- Accuracy comparison across datasets
- Model performance metrics
- Graphical visualization of results

🔹 **Contributors:** You! 🚀
